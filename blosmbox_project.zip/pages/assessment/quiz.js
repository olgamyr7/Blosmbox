import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { supabase } from "../../lib/supabaseClient";

const questions = [
  "We communicate openly and honestly.",
  "We feel emotionally safe with each other.",
  "We handle conflicts respectfully.",
  "We feel physically connected.",
  "We agree on financial priorities."
];

export default function Quiz() {
  const router = useRouter();
  const [answers, setAnswers] = useState([]);

  useEffect(() => {
    setAnswers(Array(questions.length).fill(3));
  }, []);

  async function handleSubmit() {
    const sessionId = localStorage.getItem("sessionId");
    const user = (await supabase.auth.getUser()).data.user;
    const userEmail = user?.email || "anonymous";

    const { error } = await supabase.from("answers").insert([
      { session_id: sessionId, user_email: userEmail, answers }
    ]);

    if (error) {
      alert(error.message);
      return;
    }

    router.push("/assessment/report");
  }

  return (
    <div style={{
      minHeight: "100vh",
      padding: "2rem",
      background: "#f3f3f3"
    }}>
      <div style={{
        background: "#fff",
        borderRadius: "1.5rem",
        boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
        padding: "2rem",
        maxWidth: "720px",
        margin: "0 auto"
      }}>
        <h2 style={{ fontSize: "1.8rem" }}>Assessment</h2>
        <p style={{ color: "#666", marginTop: "0.5rem" }}>
          Rate each statement from 1–5.
        </p>

        {questions.map((q, index) => (
          <div key={index} style={{ marginTop: "1.5rem" }}>
            <p style={{ fontWeight: "600" }}>{q}</p>
            <input
              type="range"
              min="1"
              max="5"
              value={answers[index]}
              onChange={(e) => {
                const newAnswers = [...answers];
                newAnswers[index] = Number(e.target.value);
                setAnswers(newAnswers);
              }}
              style={{ width: "100%" }}
            />
          </div>
        ))}

        <button
          style={{
            width: "100%",
            marginTop: "2rem",
            padding: "1rem",
            borderRadius: "1rem",
            background: "#E6C07A",
            border: "none",
            fontWeight: "bold"
          }}
          onClick={handleSubmit}
        >
          Submit
        </button>
      </div>
    </div>
  );
}
