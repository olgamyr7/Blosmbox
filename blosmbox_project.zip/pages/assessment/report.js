import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";

export default function Report() {
  const [score, setScore] = useState(0);

  useEffect(() => {
    async function fetchReport() {
      const sessionId = localStorage.getItem("sessionId");
      const { data, error } = await supabase
        .from("answers")
        .select("answers")
        .eq("session_id", sessionId);

      if (error) {
        alert(error.message);
        return;
      }

      const total = data.reduce((sum, row) => {
        const answers = row.answers;
        return sum + answers.reduce((s, a) => s + a, 0);
      }, 0);

      setScore(total);
    }

    fetchReport();
  }, []);

  return (
    <div style={{
      minHeight: "100vh",
      padding: "2rem",
      background: "#f3f3f3"
    }}>
      <div style={{
        background: "#fff",
        borderRadius: "1.5rem",
        boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
        padding: "2rem",
        maxWidth: "720px",
        margin: "0 auto"
      }}>
        <h2 style={{ fontSize: "1.8rem" }}>Your Report (Short Version)</h2>
        <p style={{ color: "#666", marginTop: "0.5rem" }}>
          Your score: <strong>{score}</strong>
        </p>
        <p style={{ marginTop: "1rem", color: "#444" }}>
          This is a premium report preview. When both partners complete the assessment,
          the full detailed report will be generated.
        </p>
      </div>
    </div>
  );
}
