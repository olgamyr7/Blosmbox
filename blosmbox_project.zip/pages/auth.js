import { useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { useRouter } from "next/router";

export default function Auth() {
  const [email, setEmail] = useState("");
  const router = useRouter();

  async function handleLogin() {
    const { error } = await supabase.auth.signInWithOtp({ email });
    if (error) {
      alert(error.message);
    } else {
      alert("Check your email for a login link.");
      router.push("/assessment/start");
    }
  }

  return (
    <div style={{
      minHeight: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      background: "#f3f3f3"
    }}>
      <div style={{
        background: "#fff",
        padding: "2rem",
        borderRadius: "1.5rem",
        boxShadow: "0 10px 30px rgba(0,0,0,0.1)",
        width: "90%",
        maxWidth: "420px"
      }}>
        <h2 style={{ fontSize: "1.8rem", marginBottom: "1rem" }}>Login / Register</h2>
        <input
          style={{
            width: "100%",
            padding: "1rem",
            borderRadius: "1rem",
            border: "1px solid #ddd",
            marginBottom: "1rem"
          }}
          placeholder="Your email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button
          style={{
            width: "100%",
            padding: "1rem",
            borderRadius: "1rem",
            background: "#E6C07A",
            border: "none",
            fontWeight: "bold"
          }}
          onClick={handleLogin}
        >
          Send Login Link
        </button>
      </div>
    </div>
  );
}
