import { useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then((s) => setUser(s.data.session?.user));
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/";
  }

  if (!user) return <div style={{ padding: "2rem" }}>Loading...</div>;

  return (
    <div style={{ padding: "2rem" }}>
      <h1 style={{ fontSize: "2rem" }}>Dashboard</h1>
      <p style={{ marginTop: "0.5rem" }}>Welcome, {user.email}</p>
      <button
        style={{
          marginTop: "1rem",
          padding: "1rem",
          borderRadius: "1rem",
          background: "#E6C07A",
          border: "none",
          fontWeight: "bold"
        }}
        onClick={handleLogout}
      >
        Logout
      </button>
    </div>
  );
}
