import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-white to-slate-100">
      <h1 style={{ fontSize: "3rem", marginBottom: "1rem" }}>BlosmBox</h1>
      <p style={{ fontSize: "1.2rem", color: "#666", textAlign: "center", maxWidth: 520 }}>
        A printable online relationship assessment for two people — complete separately on your phones.
      </p>
      <Link href="/auth">
        <a style={{
          marginTop: "2rem",
          padding: "1rem 2rem",
          background: "#E6C07A",
          color: "#fff",
          borderRadius: "1rem",
          fontWeight: "bold",
          textDecoration: "none"
        }}>
          Start Assessment
        </a>
      </Link>
    </div>
  );
}
