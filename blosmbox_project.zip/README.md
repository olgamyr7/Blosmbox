# BlosmBox (Starter)

This is a starter Next.js project for BlosmBox relationship assessment.

## Setup

1. Create a Supabase project.
2. Add tables: `sessions`, `answers`.
3. Add environment variables in Vercel:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY

## Run locally

```
npm install
npm run dev
```
